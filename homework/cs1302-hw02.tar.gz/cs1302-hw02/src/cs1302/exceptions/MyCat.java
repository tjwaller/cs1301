package cs1302.exceptions;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * A simpler version of the Unix <code>cat</code> command.
 */
public class MyCat {

    /**
     * Entry point for the application.
     * If a filename is given as an argument, then the program should print the contents of that
     * file to standard output. If a single dash (i.e., "-") is given as an argument, then
     * the program should print the contents of standard input.
     * Given multiple command line inputs, the program with print out standard input, or
     * The contents of the file or both according to the command line arguments.
     *
     * @param args  the command-line arguments
     */
    public static void main(String[] args) {

        if (args.length == 0) {
            System.err.println("Usage: MyCat [filename]...");
        }

        for (int i = 0; i < args.length; i++) {

            try {

                String filename = args[i];

                if (filename.equals("-")) {

                    Printer.printStdInLines();

                } else {

                    File file = new File(filename);

                    Printer.printFileLines(file);

                } // if



            } catch (FileNotFoundException fnfe) {

                System.err.println("MyCat: " + fnfe.toString());

            } // catch

        } // for

    } // main

} // MyCat
